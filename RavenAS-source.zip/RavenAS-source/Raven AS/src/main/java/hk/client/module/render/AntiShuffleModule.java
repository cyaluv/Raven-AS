package hk.client.module.render;

import hk.client.module.Category;
import hk.client.module.Module;

public class AntiShuffleModule extends Module {
    public static AntiShuffleModule instance;
    public static final String OBFUSCATED = "§k";

    public AntiShuffleModule(int key) {
        super("AntiShuffle", Category.render, key);
        instance = this;
    }
}
