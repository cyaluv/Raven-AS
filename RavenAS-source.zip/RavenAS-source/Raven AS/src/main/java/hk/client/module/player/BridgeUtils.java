/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Original idea and code by Caterpillow. Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.player;

import net.minecraft.block.Block;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/** Shared block placing helpers for AutoClutch and TellyBridge (client-side rotations only). */
final class BridgeUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private BridgeUtils() {
    }

    static Block block(BlockPos pos) {
        return mc.theWorld.getBlockState(pos).getBlock();
    }

    static boolean isAir(BlockPos pos) {
        Block b = block(pos);
        if (b.getMaterial().isReplaceable()) {
            return !(b instanceof BlockSnow) || !(b.getBlockBoundsMaxY() > 0.125);
        }
        return false;
    }

    static boolean slotHasBlocks(int slot) {
        ItemStack s = mc.thePlayer.inventory.getStackInSlot(slot);
        return s != null && s.getItem() instanceof ItemBlock && s.stackSize > 0;
    }

    static int firstBlockSlot() {
        for (int i = 0; i < 9; i++) {
            if (slotHasBlocks(i)) {
                return i;
            }
        }
        return -1;
    }

    static float[] rotations(BlockPos block, EnumFacing face, float partialTicks) {
        Entity e = mc.getRenderViewEntity();
        double px = e.lastTickPosX + (e.posX - e.lastTickPosX) * (double) partialTicks;
        double py = e.lastTickPosY + (e.posY - e.lastTickPosY) * (double) partialTicks;
        double pz = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * (double) partialTicks;
        double x = (double) block.getX() + 0.5 - px + (double) face.getFrontOffsetX() / 2.0;
        double z = (double) block.getZ() + 0.5 - pz + (double) face.getFrontOffsetZ() / 2.0;
        double y = (double) block.getY() + 0.5;
        double d1 = py + (double) mc.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) (Math.atan2(d1, d3) * 180.0 / Math.PI);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[]{yaw, pitch};
    }

    /**
     * Tries to place a block at pos against one of its horizontal neighbours.
     * aim: also turn the camera towards the block. place: actually right-click.
     */
    private static boolean tryPlace(BlockPos pos, boolean place, boolean aim, float partialTicks) {
        Entity e = mc.getRenderViewEntity();
        double ex = e.lastTickPosX + (e.posX - e.lastTickPosX) * (double) partialTicks;
        double ey = e.lastTickPosY + (e.posY - e.lastTickPosY) * (double) partialTicks;
        double ez = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * (double) partialTicks;
        Vec3 eyes = new Vec3(ex, ey + (double) mc.thePlayer.getEyeHeight(), ez);
        for (EnumFacing side : EnumFacing.values()) {
            if (side == EnumFacing.UP || side == EnumFacing.DOWN) {
                continue;
            }
            BlockPos neighbor = pos.offset(side);
            EnumFacing face = side.getOpposite();
            if (!block(neighbor).canCollideCheck(mc.theWorld.getBlockState(neighbor), false)) {
                continue;
            }
            Vec3 hit = new Vec3(neighbor).addVector(0.5, 0.5, 0.5).add(new Vec3(face.getDirectionVec()));
            if (eyes.squareDistanceTo(hit) > 36.0) {
                continue;
            }
            float[] angles = rotations(neighbor, face, partialTicks);
            if (aim || place) {
                mc.getRenderViewEntity().rotationYaw = angles[0];
                mc.getRenderViewEntity().rotationPitch = angles[1];
            }
            if (place) {
                mc.thePlayer.rotationYaw = angles[0];
                mc.thePlayer.rotationPitch = angles[1];
                mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.getCurrentEquippedItem(), neighbor, face, hit);
                mc.thePlayer.swingItem();
            }
            return true;
        }
        return false;
    }

    /**
     * Looks for a spot below the player (searching outwards up to range) and places or aims at it.
     * Returns the targeted position, or null if there was nothing to do.
     */
    static BlockPos placeBelow(double range, boolean place, boolean aim, boolean autoSwitch, float partialTicks) {
        BlockPos feet = new BlockPos(mc.thePlayer).down();
        if (!isAir(feet)) {
            return null;
        }
        if (autoSwitch && !slotHasBlocks(mc.thePlayer.inventory.currentItem)) {
            int slot = firstBlockSlot();
            if (slot < 0) {
                return null;
            }
            mc.thePlayer.inventory.currentItem = slot;
        }
        if (tryPlace(feet, place, aim, partialTicks)) {
            return feet;
        }
        for (int dist = 0; dist <= range; dist++) {
            for (int blockDist = 0; dist != blockDist; blockDist++) {
                for (int x = blockDist; x >= 0; x--) {
                    int z = blockDist - x;
                    int y = dist - blockDist;
                    BlockPos base = new BlockPos(mc.thePlayer).down(y);
                    BlockPos[] candidates = {
                            base.north(x).west(z), base.north(x).west(-z), base.north(-x).west(z), base.north(-x).west(-z)
                    };
                    for (BlockPos c : candidates) {
                        if (tryPlace(c, place, aim, partialTicks)) {
                            return c;
                        }
                    }
                }
            }
        }
        return null;
    }
}
