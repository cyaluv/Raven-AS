/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemStack;

public class PearlModule extends HotkeyModule {
    public PearlModule(int key) {
        super("Pearl", key, true);
    }

    private static boolean matches(int slot) {
        ItemStack s = stack(slot);
        return s != null && (s.getItem() instanceof ItemEnderPearl);
    }

    @Override
    protected void run() {
        this.selectMatching(PearlModule::matches);
    }
}
