package hk.client.module.render;

import hk.client.module.Category;
import hk.client.module.Module;
import hk.client.module.ModuleManager;
import hk.client.module.setting.SliderSetting;

public class NoHurtCamModule extends Module {
    public static NoHurtCamModule instance;
    public static SliderSetting multiplier;

    public NoHurtCamModule(int key) {
        super("NoHurtCam", Category.render, key);
        instance = this;
    }

    public void link() {
        multiplier = (SliderSetting) ModuleManager.setting(this, "Multiplier");
    }
}
