/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class LaddersModule extends HotkeyModule {
    public LaddersModule(int key) {
        super("Ladders", key, true);
    }

    private static boolean matches(int slot) {
        ItemStack s = stack(slot);
        return s != null && (s.getItem() instanceof ItemBlock && ((ItemBlock) s.getItem()).getBlock() == Blocks.ladder);
    }

    @Override
    protected void run() {
        this.selectMatching(LaddersModule::matches);
    }
}
