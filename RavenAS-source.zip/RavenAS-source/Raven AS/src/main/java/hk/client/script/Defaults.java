package hk.client.script;

import net.minecraft.client.Minecraft;

public interface Defaults {
    Minecraft mc = Minecraft.getMinecraft();
}
