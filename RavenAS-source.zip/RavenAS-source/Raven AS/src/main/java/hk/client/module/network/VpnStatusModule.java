package hk.client.module.network;

import hk.client.client.Chat;
import hk.client.module.Category;
import hk.client.module.Module;

public class VpnStatusModule extends Module {
    public VpnStatusModule(int key) {
        super("VPN Status", Category.network, key);
    }

    @Override
    public boolean canBeEnabled() {
        Chat.moduleMessage(this, "&cThere was an error, try relaunching.");
        return false;
    }
}
