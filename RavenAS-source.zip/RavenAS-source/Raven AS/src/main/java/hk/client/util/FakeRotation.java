package hk.client.util;

public enum FakeRotation {
    None,
    Smooth,
    Forward,
    Spin
}
