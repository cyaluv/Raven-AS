/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemStack;

public class ProjectilesModule extends HotkeyModule {
    public ProjectilesModule(int key) {
        super("Projectiles", key, true);
    }

    private static boolean matches(int slot) {
        ItemStack s = stack(slot);
        return s != null && (s.getItem() instanceof ItemSnowball || s.getItem() instanceof ItemEgg || s.getItem() instanceof ItemFishingRod);
    }

    @Override
    protected void run() {
        this.selectMatching(ProjectilesModule::matches);
    }
}
