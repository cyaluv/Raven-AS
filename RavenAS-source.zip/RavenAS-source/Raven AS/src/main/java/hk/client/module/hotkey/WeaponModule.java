/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;

public class WeaponModule extends HotkeyModule {
    public WeaponModule(int key) {
        super("Weapon", key, false);
    }

    private static double damage(ItemStack s) {
        double d = 0.0;
        for (AttributeModifier m : s.getAttributeModifiers().get(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName())) {
            if (m.getOperation() == 0) {
                d += m.getAmount();
            }
        }
        if (d > 0.0) {
            d += 1.25 * EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, s);
        }
        return d;
    }

    @Override
    protected void run() {
        int best = -1;
        double bestDamage = 0.0;
        for (int slot = 0; slot <= 8; slot++) {
            ItemStack s = stack(slot);
            if (s == null) {
                continue;
            }
            double d = damage(s);
            if (d > bestDamage) {
                bestDamage = d;
                best = slot;
            }
        }
        if (best > -1) {
            mc.thePlayer.inventory.currentItem = best;
        }
    }
}
