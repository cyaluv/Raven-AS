package hk.client.module.render;

import hk.client.module.Category;
import hk.client.module.Module;

public class NoCameraClipModule extends Module {
    public static NoCameraClipModule instance;

    public NoCameraClipModule(int key) {
        super("NoCameraClip", Category.render, key);
        instance = this;
    }
}
