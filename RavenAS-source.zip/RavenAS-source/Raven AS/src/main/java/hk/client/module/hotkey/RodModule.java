/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import hk.client.module.ModuleManager;
import hk.client.module.setting.SliderSetting;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.concurrent.ThreadLocalRandom;

/** Switches to a fishing rod and casts it, holding use for a short random delay (tick based, never blocks the game). */
public class RodModule extends HotkeyModule {
    private SliderSetting minDelay, maxDelay;
    private boolean pressing;
    private long releaseAt;

    public RodModule(int key) {
        super("Rod", key, true);
    }

    @Override
    public void link() {
        super.link();
        this.minDelay = (SliderSetting) ModuleManager.setting(this, "Min delay");
        this.maxDelay = (SliderSetting) ModuleManager.setting(this, "Max delay");
    }

    private static boolean matches(int slot) {
        ItemStack s = stack(slot);
        return s != null && s.getItem() instanceof ItemFishingRod;
    }

    @Override
    public void onEnable() {
        this.pressing = false;
        if (inGame()) {
            ItemStack held = mc.thePlayer.getHeldItem();
            if (held != null && held.getItem() instanceof ItemFishingRod) {
                this.disable();
                return;
            }
            int before = mc.thePlayer.inventory.currentItem;
            if (this.selectMatching(RodModule::matches) && mc.thePlayer.inventory.currentItem != before) {
                int lo = (int) Math.min(this.minDelay.getInput(), this.maxDelay.getInput());
                int hi = (int) Math.max(this.minDelay.getInput(), this.maxDelay.getInput());
                long delay = lo == hi ? lo : ThreadLocalRandom.current().nextInt(lo, hi + 1);
                this.releaseAt = System.currentTimeMillis() + delay;
                this.pressing = true;
                int code = mc.gameSettings.keyBindUseItem.getKeyCode();
                KeyBinding.setKeyBindState(code, true);
                KeyBinding.onTick(code);
                return;
            }
        }
        this.disable();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !this.pressing) {
            return;
        }
        if (mc.thePlayer == null || System.currentTimeMillis() >= this.releaseAt) {
            this.disable();
        }
    }

    @Override
    public void onDisable() {
        if (this.pressing) {
            this.pressing = false;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        }
    }

    @Override
    protected void run() {
    }
}
