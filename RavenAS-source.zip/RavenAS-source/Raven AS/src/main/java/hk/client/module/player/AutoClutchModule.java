/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Original idea and code by Caterpillow. Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.player;

import hk.client.module.Category;
import hk.client.module.Module;
import hk.client.module.ModuleManager;
import hk.client.module.setting.ButtonSetting;
import hk.client.module.setting.SliderSetting;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Places blocks under you automatically when you are over air. Uses client-side rotations. */
public class AutoClutchModule extends Module {
    private SliderSetting range;
    private ButtonSetting cpsCap;

    public AutoClutchModule(int key) {
        super("AutoClutch", Category.player, key);
    }

    @Override
    public void link() {
        this.range = (SliderSetting) ModuleManager.setting(this, "Range");
        this.cpsCap = (ButtonSetting) ModuleManager.setting(this, "Cps cap");
    }

    private static boolean ready() {
        return mc.thePlayer != null && mc.theWorld != null && mc.currentScreen == null;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !ready() || !this.cpsCap.enabled) {
            return;
        }
        BridgeUtils.placeBelow(this.range.getInput(), true, true, true, 1.0f);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL || !ready()) {
            return;
        }
        BridgeUtils.placeBelow(this.range.getInput(), !this.cpsCap.enabled, true, true, e.partialTicks);
    }
}
