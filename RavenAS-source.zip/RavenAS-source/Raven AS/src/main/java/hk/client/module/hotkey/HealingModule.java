/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import hk.client.module.ModuleManager;
import hk.client.module.setting.SliderSetting;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSoup;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class HealingModule extends HotkeyModule {
    private SliderSetting mode;

    public HealingModule(int key) {
        super("Healing", key, true);
    }

    @Override
    public void link() {
        super.link();
        this.mode = (SliderSetting) ModuleManager.setting(this, "Mode");
    }

    private static boolean isHealPotion(ItemStack s) {
        if (!(s.getItem() instanceof ItemPotion)) {
            return false;
        }
        java.util.List<PotionEffect> effects = ((ItemPotion) s.getItem()).getEffects(s);
        if (effects == null) {
            return false;
        }
        for (PotionEffect e : effects) {
            if (e.getPotionID() == Potion.heal.id) {
                return true;
            }
        }
        return false;
    }

    private boolean matches(int slot) {
        ItemStack s = stack(slot);
        if (s == null) {
            return false;
        }
        switch ((int) this.mode.getInput()) {
            case 0: return isHealPotion(s);
            case 1: return s.getItem() instanceof ItemSoup;
            case 2: return s.getItem() instanceof ItemAppleGold;
            case 3: return s.getItem() instanceof ItemFood;
            default: return isHealPotion(s) || s.getItem() instanceof ItemSoup || s.getItem() instanceof ItemFood;
        }
    }

    @Override
    protected void run() {
        this.selectMatching(this::matches);
    }
}
