/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Original idea and code by Caterpillow. Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.player;

import hk.client.client.Chat;
import hk.client.module.Category;
import hk.client.module.Module;
import hk.client.module.ModuleManager;
import hk.client.module.setting.SliderSetting;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Runs forward and jumps, then turns back and places blocks behind you (telly bridging). Client-side rotations. */
public class TellyBridgeModule extends Module {
    private enum Phase {
        PreJump, Turn, Jump, Jumping, Placing
    }

    private SliderSetting bufferDistance;
    private Phase phase = Phase.PreJump;
    private float startYaw, startPitch;
    private BlockPos lastBlock;

    public TellyBridgeModule(int key) {
        super("TellyBridge", Category.player, key);
    }

    @Override
    public void link() {
        this.bufferDistance = (SliderSetting) ModuleManager.setting(this, "Buffer distance");
    }

    private static void keys(boolean forward, boolean back, boolean jump) {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), forward);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), back);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), jump);
    }

    @Override
    public void onEnable() {
        if (mc.thePlayer != null && mc.theWorld != null && mc.inGameHasFocus) {
            this.startYaw = mc.thePlayer.rotationYaw;
            this.startPitch = mc.thePlayer.rotationPitch;
            this.phase = Phase.PreJump;
            BlockPos below = new BlockPos(mc.thePlayer).down();
            this.lastBlock = BridgeUtils.isAir(below) ? null : below;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
        } else {
            this.disable();
        }
    }

    @Override
    public void onDisable() {
        if (mc.gameSettings != null) {
            keys(false, false, false);
        }
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL || mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
        if (this.phase == Phase.Placing) {
            BridgeUtils.placeBelow((int) mc.playerController.getBlockReachDistance(), false, true, false, e.partialTicks);
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
        if (this.lastBlock == null) {
            Chat.print("&cTellyBridge: stand on a block before enabling.");
            this.disable();
            return;
        }
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
        if (Math.sqrt(mc.thePlayer.getDistanceSq(this.lastBlock)) > this.bufferDistance.getInput()) {
            this.phase = Phase.Placing;
        } else if (!BridgeUtils.isAir(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 0.2, mc.thePlayer.posZ)) && this.phase == Phase.Placing) {
            this.phase = Phase.Turn;
        } else if (mc.thePlayer.isCollidedVertically && this.phase == Phase.Turn) {
            this.phase = Phase.Jump;
        }
        switch (this.phase) {
            case Turn:
            case PreJump:
                mc.thePlayer.rotationYaw = this.startYaw;
                mc.thePlayer.rotationPitch = this.startPitch;
                keys(true, false, false);
                this.phase = Phase.Jump;
                break;
            case Jump:
                mc.thePlayer.rotationYaw = this.startYaw;
                mc.thePlayer.rotationPitch = this.startPitch;
                keys(true, false, true);
                this.phase = Phase.Jumping;
                break;
            case Jumping:
                keys(true, false, true);
                break;
            case Placing:
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), true);
                BlockPos placed = BridgeUtils.placeBelow((int) mc.playerController.getBlockReachDistance(), true, true, false, 1.0f);
                if (placed != null) {
                    this.lastBlock = placed;
                }
                break;
        }
    }
}
