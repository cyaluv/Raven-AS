/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import hk.client.module.ModuleManager;
import hk.client.module.setting.ButtonSetting;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

/** Switches to a hotbar armor piece you can equip (right-click to put it on). */
public class ArmorModule extends HotkeyModule {
    private ButtonSetting ignoreIfEquipped;

    public ArmorModule(int key) {
        super("Armor", key, false);
    }

    @Override
    public void link() {
        this.ignoreIfEquipped = (ButtonSetting) ModuleManager.setting(this, "Ignore if equipped");
    }

    @Override
    protected void run() {
        for (int type = 0; type < 4; type++) {
            ItemStack worn = mc.thePlayer.inventory.armorInventory[3 - type];
            if (worn != null && this.ignoreIfEquipped.enabled) {
                continue;
            }
            int wornValue = worn != null && worn.getItem() instanceof ItemArmor
                    ? ((ItemArmor) worn.getItem()).getArmorMaterial().getDamageReductionAmount(type) : -1;
            int best = -1;
            int bestValue = wornValue;
            for (int slot = 0; slot <= 8; slot++) {
                ItemStack s = stack(slot);
                if (s == null || !(s.getItem() instanceof ItemArmor)) {
                    continue;
                }
                ItemArmor a = (ItemArmor) s.getItem();
                if (a.armorType != type) {
                    continue;
                }
                int value = a.getArmorMaterial().getDamageReductionAmount(type);
                if (value > bestValue) {
                    bestValue = value;
                    best = slot;
                }
            }
            if (best > -1) {
                mc.thePlayer.inventory.currentItem = best;
                return;
            }
        }
    }
}
