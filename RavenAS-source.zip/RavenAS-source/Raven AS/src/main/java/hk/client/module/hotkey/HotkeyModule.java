/*
 * Ported from RavenWeave (https://github.com/PianoPenguin471/RavenWeave), licensed under GPLv3.
 * Rewritten for the Raven AS / OpenB4 module system.
 */
package hk.client.module.hotkey;

import hk.client.module.Category;
import hk.client.module.Module;
import hk.client.module.ModuleManager;
import hk.client.module.setting.ButtonSetting;
import hk.client.module.setting.SliderSetting;
import net.minecraft.entity.player.InventoryPlayer;

import java.util.function.IntPredicate;

/** Base for "press the bind once, switch to the right hotbar item" modules. */
public abstract class HotkeyModule extends Module {
    protected ButtonSetting preferSlot;
    protected SliderSetting preferSlotNumber;
    private final boolean hasPreference;

    protected HotkeyModule(String name, int key, boolean hasPreference) {
        super(name, Category.hotkey, key);
        this.hasPreference = hasPreference;
    }

    @Override
    public void link() {
        if (this.hasPreference) {
            this.preferSlot = (ButtonSetting) ModuleManager.setting(this, "Prefer a slot");
            this.preferSlotNumber = (SliderSetting) ModuleManager.setting(this, "Prefer which slot");
        }
    }

    protected static boolean inGame() {
        return mc.thePlayer != null && mc.theWorld != null;
    }

    @Override
    public void onEnable() {
        if (inGame()) {
            this.run();
        }
        this.disable();
    }

    protected abstract void run();

    /** Selects a hotbar slot whose item matches. Returns true if a matching item is now held. */
    protected boolean selectMatching(IntPredicate matches) {
        InventoryPlayer inv = mc.thePlayer.inventory;
        if (this.hasPreference && this.preferSlot.enabled) {
            int p = (int) this.preferSlotNumber.getInput() - 1;
            if (p >= 0 && p <= 8 && matches.test(p)) {
                inv.currentItem = p;
                return true;
            }
        }
        if (matches.test(inv.currentItem)) {
            return true;
        }
        for (int slot = 0; slot <= 8; slot++) {
            if (matches.test(slot)) {
                inv.currentItem = slot;
                return true;
            }
        }
        return false;
    }

    protected static net.minecraft.item.ItemStack stack(int slot) {
        return mc.thePlayer.inventory.getStackInSlot(slot);
    }
}
